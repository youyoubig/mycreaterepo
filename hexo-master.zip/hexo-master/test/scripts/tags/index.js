'use strict';

describe('Tags', () => {
  require('./asset_img');
  require('./asset_link');
  require('./asset_path');
  require('./blockquote');
  require('./code');
  require('./gist');
  require('./iframe');
  require('./img');
  require('./include_code');
  require('./jsfiddle');
  require('./link');
  require('./post_link');
  require('./post_path');
  require('./pullquote');
  require('./vimeo');
  require('./youtube');
});
